import React from "react";

const CustomersContext = React.createContext({
  customers: [],
});

export default CustomersContext;
