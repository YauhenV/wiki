import Customers from "./components/Customers";

function App() {
  return (
    <div>
      <Customers />
    </div>
  );
}

export default App;
